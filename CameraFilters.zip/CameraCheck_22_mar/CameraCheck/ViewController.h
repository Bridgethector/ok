//
//  ViewController.h
//  CameraCheck
//
//  Created by outthinking on 3/18/16.
//  Copyright © 2016 outthinking. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreImage/CoreImage.h>

#import "GPUImage.h"

@interface ViewController : UIViewController<UINavigationBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate,GPUImageVideoCameraDelegate>

{
    UIView *view,*viewCamera;
    
    GPUImageStillCamera *stillCamera;
    GPUImageVideoCamera *videoCamera;
    GPUImageOutput<GPUImageInput> *filter;
    
    IBOutlet GPUImageView *cameraView;
    UIButton * frontcamera;
    
    
    
}
@property (weak,nonatomic) IBOutlet UIScrollView *filterScrollView;


- (IBAction)saveImageToAlbum:(id)sender;
- (IBAction)photoFromAlbum:(id)sender;
- (IBAction)applyImageFilter:(id)sender;
- (IBAction)photoFromCamera:(id)sender;





@end

