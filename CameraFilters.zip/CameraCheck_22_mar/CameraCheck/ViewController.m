//
//  ViewController.m
//  CameraCheck
//
//  Created by outthinking on 3/18/16.
//  Copyright © 2016 outthinking. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()
{
    GPUImageFilter *selectedFilter;
    

}

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    //......Tag......//
    frontcamera.tag = 1;
    
    //.......FrontcamButton........//
    frontcamera = [[UIButton alloc]initWithFrame:CGRectMake(245, 80, 60, 40)];
    
    
    
    [frontcamera setTitle:@"Cam" forState:UIControlStateNormal];
    
    
    
    [frontcamera setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    
    
    
    frontcamera.layer.cornerRadius = 10;
    
    
    
    [frontcamera addTarget:self action:@selector(frontCameraView:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    [frontcamera setBackgroundColor:[UIColor cyanColor]];
    
    
    
    [self.view addSubview:frontcamera];
    

   
    cameraView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

    //stillCamera = [[GPUImageStillCamera alloc] init];
    stillCamera = [[GPUImageStillCamera alloc]
                   initWithSessionPreset:AVCaptureSessionPresetPhoto
                   cameraPosition:AVCaptureDevicePositionBack];

    stillCamera.outputImageOrientation = UIInterfaceOrientationPortrait;
    
    filter = [[GPUImageGammaFilter alloc] init];
    [stillCamera addTarget:filter];
    [stillCamera addTarget:cameraView];
    
    [stillCamera startCameraCapture];
    
    
    [self addButtonsToScrollView];
    
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    // Note: I needed to start camera capture after the view went on the screen, when a partially transition of navigation view controller stopped capturing via viewWilDisappear.
}
//.........ChangingCamera.........//
-(void)frontCameraView:(UIButton*)changeCam
{
    if (changeCam.tag==1) {
        stillCamera = [[GPUImageStillCamera alloc]
                       initWithSessionPreset:AVCaptureSessionPresetPhoto
                       cameraPosition:AVCaptureDevicePositionFront];
        
        stillCamera.outputImageOrientation = UIInterfaceOrientationPortrait;
        
        filter = [[GPUImageGammaFilter alloc] init];
        [stillCamera addTarget:filter];
        [stillCamera addTarget:cameraView];
        
        [stillCamera startCameraCapture];
        changeCam.tag=0;
        
        

    } else {
        stillCamera = [[GPUImageStillCamera alloc]
                       initWithSessionPreset:AVCaptureSessionPresetPhoto
                       cameraPosition:AVCaptureDevicePositionBack];
        
        stillCamera.outputImageOrientation = UIInterfaceOrientationPortrait;
        
        filter = [[GPUImageGammaFilter alloc] init];
        [stillCamera addTarget:filter];
        [stillCamera addTarget:cameraView];
        
        [stillCamera startCameraCapture];
        changeCam.tag=1;

    }
}

- (void)addButtonsToScrollView
{
    NSArray *buttons = @[@{@"Tag":@1,@"Title":@"Invert",@"Color":[UIColor redColor]},
                         @{@"Tag":@2,@"Title":@"Sketch",@"Color":[UIColor blueColor]},
                         @{@"Tag":@3,@"Title":@"RGB",@"Color":[UIColor greenColor]},
                         @{@"Tag":@4,@"Title":@"Halftone",@"Color":[UIColor redColor]},
                         @{@"Tag":@5,@"Title":@"Brightness",@"Color":[UIColor blueColor]},
                         @{@"Tag":@6,@"Title":@"False Color",@"Color":[UIColor greenColor]},
                         @{@"Tag":@7,@"Title":@"Contrast",@"Color":[UIColor blueColor]},
                         @{@"Tag":@8,@"Title":@"Bulge",@"Color":[UIColor greenColor]}];
    
    CGRect frame = CGRectMake(5.0f, 5.0f, 50.0f, 50.0f);
    for (NSDictionary *dict in buttons)
    {
        UIButton *button =[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame = frame;
        button.tag = [dict[@"Tag"] integerValue];
        [button setTitle:dict[@"Title"]
                forState:UIControlStateNormal];
        button.backgroundColor = dict[@"Color"];
        [button setTitleColor:[UIColor blackColor]
                     forState:UIControlStateNormal];
        [button addTarget:self action:@selector(performFilterToCamera:)
         forControlEvents:UIControlEventTouchUpInside];
        [self.filterScrollView addSubview:button];
        frame.origin.x+=frame.size.width+15.0f;
    }
    
    CGSize contentSize = self.filterScrollView.frame.size;
    contentSize.width = frame.origin.x;
    self.filterScrollView.contentSize = contentSize;


}
-(void)performFilterToCamera:(UIButton *)sender
{
    [filter removeAllTargets];
    [stillCamera removeAllTargets];
    switch (sender.tag) {
        case 1:{
            NSLog(@"value:%@",sender.titleLabel.text);
            filter = [[GPUImageColorInvertFilter alloc] init];
        }
            break;
        case 2:{
            NSLog(@"value:%@",sender.titleLabel.text);
            filter = [[GPUImageSketchFilter alloc] init];
        }
            break;
        case 3:{
            NSLog(@"value:%@",sender.titleLabel.text);
            filter = [[GPUImageRGBFilter alloc] init];
        }
            break;
        case 4:{
            NSLog(@"value:%@",sender.titleLabel.text);
            filter = [[GPUImageHalftoneFilter alloc] init];
        }
            break;
        case 5:{
            NSLog(@"value:%@",sender.titleLabel.text);
            filter = [[GPUImageBrightnessFilter alloc] init];
        }
            break;
        case 6:{
            NSLog(@"value:%@",sender.titleLabel.text);
            filter = [[GPUImageFalseColorFilter alloc] init];
        }
            break;
        case 7:
            NSLog(@"value:%@",sender.titleLabel.text);
            filter = [[GPUImageContrastFilter alloc] init];
            break;
        case 8:
            NSLog(@"value:%@",sender.titleLabel.text);
            filter = [[GPUImageBulgeDistortionFilter alloc] init];
            break;
            
        default:
            break;
    }
    
    [stillCamera addTarget:filter];
    [filter addTarget:cameraView];
    [stillCamera startCameraCapture];
}



- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    UIAlertView *alert;
    if (!error)
    {
        alert=[[UIAlertView alloc]initWithTitle:@"Success" message:@"Your image successfully saved to gallary." delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    }
    else
    {
        alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Your iamge has not been saved." delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    }
    [alert show];
}

- (IBAction)saveImageToAlbum:(id)sender
{
    [stillCamera capturePhotoAsImageProcessedUpToFilter:filter withCompletionHandler:^(UIImage *processedImage, NSError *error) {
        UIImageWriteToSavedPhotosAlbum(processedImage, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
    }];
    
}


- (IBAction)photoFromAlbum:(id)sender
{

    
}

- (IBAction)photoFromCamera:(id)sender
{
    
}




- (void)imagePickerController:(UIImagePickerController *)photoPicker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    
    // UIImage *selectedImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    //[self.selectedImageview setImage:selectedImage];
    
    //originalImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    
    //[self.selectedImageview setImage:originalImage];
    //[self dismissViewControllerAnimated:YES completion:NULL];
}


-(void)applyfiter
{
    //GPUImageVideoCamera *videoCamera;
    //GPUImageOutput<GPUImageInput> *filter;
    //GPUImagePicture *sourcePicture;
    //GPUImageShowcaseFilterType filterType;
    //GPUImageUIElement *uiElementInput;

        videoCamera = [[GPUImageVideoCamera alloc] initWithSessionPreset:AVCaptureSessionPreset640x480 cameraPosition:AVCaptureDevicePositionBack];
        //    videoCamera = [[GPUImageVideoCamera alloc] initWithSessionPreset:AVCaptureSessionPreset1280x720 cameraPosition:AVCaptureDevicePositionBack];
        //    videoCamera = [[GPUImageVideoCamera alloc] initWithSessionPreset:AVCaptureSessionPreset1920x1080 cameraPosition:AVCaptureDevicePositionBack];
        //    videoCamera = [[GPUImageVideoCamera alloc] initWithSessionPreset:AVCaptureSessionPreset640x480 cameraPosition:AVCaptureDevicePositionFront];
        videoCamera.outputImageOrientation = UIInterfaceOrientationPortrait;
        //facesSwitch.hidden = YES;
       // facesLabel.hidden = YES;
        //BOOL needsSecondImage = NO;
        

    [videoCamera addTarget:selectedFilter];
    [videoCamera startCameraCapture];

    //UIImage *filteredImage = [selectedFilter imageByFilteringImage:originalImage];
    
    //[self.selectedImageview setImage:filteredImage];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
